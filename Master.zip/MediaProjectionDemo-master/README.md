Android Lollipop 5.0 MediaProjectionManager Demo
------------------------------------------------
This is a sample app that demonstrates how to capture screenshots based on the MediaProjection API.
More on the API can be found in https://developer.android.com/reference/android/media/projection/package-summary.html
Clone and import the project in Android Studio. No special dependencies and extra libraries required.
Note that in order to run the code you need to create a device running Lollipop and above.